﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BinaryDisplay
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a number:");
            int number = int.Parse(Console.ReadLine());
            var BinaryForm = new Binary();
            var str = BinaryForm.ToBinary(number);
            var onesNumber = BinaryForm.OnesNumber(number);
            Console.WriteLine(str);
            Console.WriteLine(onesNumber);
            Console.ReadLine();
        }
    }
}
