﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BinaryDisplay
{
    public class Binary : IBinary
    {
        public string ToBinary(int x)
        {
            var binary = Convert.ToString(x, 2);
            return binary;
        }
        public int OnesNumber(int x)
        {
            int count = 0;
            while (x != 0)
            {
                count += x & 1;
                x = x >> 1;  
            }
            return count;
        }
    }
}
