﻿namespace BinaryDisplay
{
    public interface IBinary
    {
        int OnesNumber(int x);
        string ToBinary(int x);
    }
}