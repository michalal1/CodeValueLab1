﻿using System;
using BinaryDisplay;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestBinaryDisplay
{
    [TestClass]
    public class UnitTestBinary
    {
        [TestMethod]
        public void Binary_Tobinary_Positive()
        {
            var binary = new Binary();
            string str = binary.ToBinary(13);
            Assert.AreEqual("1101", str);          
        }

        [TestMethod]
        public void Binary_OnesNumber_Positive()
        {
            var binary = new Binary();
            int num = binary.OnesNumber(13);
            Assert.AreEqual(3, num);
        }
        
        [TestMethod]
        public void Binary_Tobinary_Negative()
        {
            var binary = new Binary();
            string str = binary.ToBinary(-13);
            
            Assert.AreEqual("11111111111111111111111111110011", str);
        }

        [TestMethod]
        public void Binary_OnesNumber_Negative()
        {
            var binary = new Binary();
            int num = binary.OnesNumber(-13);
            Assert.AreEqual(30, num);
        }

    }
}
