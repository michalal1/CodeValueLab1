﻿using System;
using System.Collections;

namespace Primes
{
    class Program
    {
        static public int[] CalcPrimes(int x, int y)
        {
            ArrayList primesList = new ArrayList();
            int first;
            int last;
            if (x < y)
            {
                first = x;
                last = y;
            }
            else
            { 
                first = y;
                last = x; 
            }
            while (first < last)
            {
                if (isPrime(first))
                {
                    primesList.Add(first);
                }
                first++;
            }
            int[] primesArray= new int[primesList.Count];
            primesList.CopyTo(primesArray);
            return primesArray;
        }

        public static bool isPrime(int x)
        {
            int y = x-1;
            while (y > 1)
            {
                if (x % y == 0)
                    return false;
                y--;
            }
            return true;
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Enter two positive numbers:");
            var input = Console.ReadLine().Split(new[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);

            if (2 > input.Length)
            {
                Console.WriteLine("Error: more than 2 parameters were entered.");
            }
            var number1 = int.Parse(input[0]);
            var number2 = int.Parse(input[1]);
            if (number1 <= 0 || number2 <= 0)
            {
                Console.WriteLine("Error: you entered negative numbers.");
                return;
            }
            int[] res=CalcPrimes(number1, number2);
            foreach (int i in res)
            {
                Console.WriteLine(i);
            }
            
            Console.ReadLine();
        }
    }
}
