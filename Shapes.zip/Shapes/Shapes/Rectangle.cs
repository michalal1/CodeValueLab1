﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shapes
{
    public class Rectangle : Shape
    {
        int _width;
        int _height;

        public Rectangle(int myWidth, int myHeight)
        {
            _width = myWidth;
            _height = myHeight;
        }

        public Rectangle(ConsoleColor color, int myWidth, int myHeight)
            : base(color)
        {
            _width = myWidth;
            _height = myHeight;
        }
        public override double Area
        {
            get { return _height * _width; }
        }
       
        public override void Display()
        {
            base.Display();
            Console.WriteLine(_width);
            Console.WriteLine(_height);
        }

        public void Write(StringBuilder sb)
        {
            sb.AppendLine("The Rectangle height is: ");
            sb.AppendLine(_height.ToString());
            sb.AppendLine("The Rectangle width is: ");
            sb.AppendLine(_width.ToString());
            Console.WriteLine(sb);
        }

        public bool IComparable(Rectangle r)
        {
            return (_width == r._width && _height == r._height);
        }
    }
}
