﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shapes
{
    public class Ellipse : Shape
    {
        int _radiusA;
        int _radiusB;

        public Ellipse(int radiusA, int radiusB)
        {
            _radiusA = radiusA;
            _radiusB = radiusB;
        }
        public override double Area
        {
            get { return  _radiusA* _radiusB *Math.PI; }
        }
      
        public override void Display()
        {
            base.Display();
            Console.WriteLine(_radiusA);
            Console.WriteLine(_radiusB);
        }

        public void Write(StringBuilder sb)
        {
            sb.AppendLine("The Ellipse radiuses are: ");
            sb.AppendLine(_radiusA.ToString());
            sb.AppendLine(_radiusB.ToString());
            Console.WriteLine(sb);
        }

        public bool IComparable(Ellipse e)
        {
            return (_radiusA == e._radiusA && _radiusB == e._radiusB);   
        }
    }
}
