﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shapes
{
    public abstract class  Shape : IPersist
    {
        ConsoleColor _color;
        public Shape(ConsoleColor myColor)
        {
            _color = myColor;
        }
        public Shape()
        {
            _color = ConsoleColor.White;
        }
        public virtual void Display()
        {
            Console.ForegroundColor = _color;
        }
        public abstract double Area { get; }

        void IPersist.Write(StringBuilder sb){}
    }
}
