﻿using System.Text;
namespace Shapes
{
    public interface IPersist
    {
        void Write(StringBuilder sb);
    }
}