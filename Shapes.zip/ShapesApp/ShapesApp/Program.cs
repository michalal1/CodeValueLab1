﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Shapes;

namespace ShapesApp
{
    public class program
    {
        public static void Main(string[] args)
        {
            var MyShapeManager = new ShapeManager();
            var MyRectangle = new Rectangle(ConsoleColor.Cyan, 4,6);
            var MyEllipse = new Ellipse(4, 6);
            var MyCircle = new Circle(4);
            MyShapeManager.Add(MyRectangle);
            MyShapeManager.Add(MyEllipse);
            MyShapeManager.Add(MyCircle);
            MyShapeManager.DisplayAll();
            var sb= new StringBuilder();
            MyShapeManager.Save(sb);
            Console.ReadLine();
        }
    }
}
