﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Shapes;

namespace ShapesApp
{
    class ShapeManager
    {
        ArrayList ShapeArray = new ArrayList();
        public void Add(Shape newShape)
        {
            ShapeArray.Add(newShape);
        }
        public void  DisplayAll()
        {
            foreach( var item in ShapeArray)
            {
                var shape = item as Shape;
                shape.Display();
                Console.WriteLine("The shape area is: {0}", shape.Area);
            }
        }

        public Shape getShape(int i)
        {
            var shape = ShapeArray[i] as Shape;
            return shape;
        }

        public int Count()
        {   
            return ShapeArray.Count;
        }

        public void Save(StringBuilder sb)
        {
            foreach (var item in ShapeArray)
            {
                var shape = item as Shape;
                if (shape is Rectangle)
                {
                    var myRectangle = item as Rectangle;
                    myRectangle.Write(sb);
                }
                if (shape is Ellipse)
                {
                    var myEllipse = item as Ellipse;
                    myEllipse.Write(sb);
                }
            }
        }


    }
}
