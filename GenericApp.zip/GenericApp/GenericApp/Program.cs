﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericApp
{
    class Program
    {
        static void Main(string[] args)
        {
            var myDictionary = new MultiDictionary<int, string>();
            myDictionary.Add(1, "one");
            myDictionary.Add(2, "two");
            myDictionary.Add(3, "three");
            myDictionary.Add(1, "ich");
            myDictionary.Add(2, "nee");
            myDictionary.Add(3, "sun");
            foreach (int key in myDictionary.Keys)
            {
                Console.WriteLine(key);
            }
            foreach (string str in myDictionary.Values)
            {
                Console.WriteLine(str);
            }

            Console.ReadLine();
        }
    }
}
