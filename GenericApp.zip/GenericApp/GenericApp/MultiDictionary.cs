﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericApp
{
    public class MultiDictionary<K,V> : IMultiDictionary<K, V>, IEnumerable<KeyValuePair<K, IEnumerable<V>>>
    {
        private Dictionary<K, LinkedList<V>> _dictionary;
        public MultiDictionary()
        {
            _dictionary = new Dictionary<K, LinkedList<V>>();
        }

        public void Add(K key, V value)
        {
            LinkedList<V> newList= new LinkedList<V>();
            if (_dictionary.ContainsKey(key))
            {
                if (_dictionary.TryGetValue(key, out newList))
                {
                    newList.AddLast(value);
                }  
            }
            else
            {
                newList.AddLast(value);
                _dictionary.Add(key, newList);
            }
        }

        public bool Remove(K key)
        {
            LinkedList<V> newList;
            if (_dictionary.TryGetValue(key, out newList))
                return _dictionary.Remove(key);
            return false;
        }

        public bool Remove(K key, V value)
        {
            LinkedList<V> newList;
            if (_dictionary.TryGetValue(key, out newList))
                return newList.Remove(value);
            return false;
        }

        public void Clear()
        {
            _dictionary.Clear();
        }

        public bool ContainsKey(K key)
        {
            return _dictionary.ContainsKey(key);
        }

        public bool Contains(K key, V value)
        {
            LinkedList<V> newList;
            if (_dictionary.TryGetValue(key, out newList))
                return newList.Contains(value);
            return false;
        }

        public int Count
        {
            get
            {
                int totalItems = 0;
                LinkedList<V> newList = new LinkedList<V>();
                foreach (K key in _dictionary.Keys)
                {
                    if (_dictionary.TryGetValue(key, out newList))
                    {
                        totalItems += newList.Count;
                    }
                }
                return totalItems;
            }
        }

        public ICollection<K> Keys
        {
            get { return _dictionary.Keys; }
        }

        public ICollection<V> Values
        {
            get
            {
                LinkedList<V> allValues = new LinkedList<V>();
                LinkedList<V> newList;
                foreach (K key in _dictionary.Keys)
                {
                    if (_dictionary.TryGetValue(key, out newList))
                    {
                        foreach (V value in newList)
                        {
                            allValues.AddLast(value);
                        }
                    }
                }
                return allValues;
            }
        }

        public IEnumerator<KeyValuePair<K, IEnumerable<V>>> GetEnumerator()
        {
            foreach (var pair in _dictionary)
            {
                yield return new KeyValuePair<K, IEnumerable<V>>(pair.Key, pair.Value);
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return _dictionary.GetEnumerator();
        }

        public object this[K key]
        {
            get { return _dictionary[key]; }
        }

    }
}
