﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloPerson
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("What's your name?");
            string name = Console.ReadLine();
            Console.WriteLine("Hello "+ name);
            Console.WriteLine("Enter a number in the range 1-10:");
            int n=int.Parse(Console.ReadLine());
            for(int i=0; i<n; i++)
            {
                char c =' ';
                Console.WriteLine(name.PadLeft(name.Length+i, c));
            }
            Console.ReadLine();

        }
    }
}
