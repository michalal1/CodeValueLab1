﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomersApp 
{
    public class Customer : IComparable<Customer>, IEquatable<Customer>
    {
        string _name;
        int _id;
        string _address;
        public Customer(string name, int id, string address)
        {
            _name=name;
            _id=id;
            _address=address;
        }
        public string Name{ get { return _name; } }
        public int ID { get { return _id; } }
        public string Address { get { return _address; } }

        public virtual int CompareTo(Customer other)
        {
            if (other == null)
                return 1;
            return string.Compare(Name, other.Name, StringComparison.Ordinal);
        }

        public bool Equals(Customer other)
        {
            return (ID == other.ID && Name == other.Name);
        }
    }
}
