﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomersApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Customer[] CustomserArray= new Customer[3];
            CustomserArray[0] = new Customer("Dani", 20, "sscsa");
            CustomserArray[1] = new Customer("Gil", 10, "sscsdsa");
            CustomserArray[2] = new Customer("Adi", 11, "sscvsvsa");
            foreach (Customer cus in CustomserArray)
            {
                Console.WriteLine(cus.Name);
            }
            Array.Sort(CustomserArray);
            foreach (Customer cus in CustomserArray)
            {
                Console.WriteLine(cus.Name);
            }
            AnotherCustomerComparer comp = new AnotherCustomerComparer();
            Array.Sort(CustomserArray,comp);
            foreach (Customer cus in CustomserArray)
            {
                Console.WriteLine(cus.Name);
            }
            Console.ReadLine();
        }
    }
}
