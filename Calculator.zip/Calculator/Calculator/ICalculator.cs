﻿namespace Calculator
{
    public interface ICalculator
    {
        double Calculate(char op, double a, double b);
        double Add(double a, double b);
        double Sub(double a, double b);
        double Mul(double a, double b);
        double Div(double a, double b);
    }
}