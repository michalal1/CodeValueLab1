﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator
{
    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter two numbers and an operator in the form 'number_1 operator number_2' :");
            var input = Console.ReadLine().Split(new[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);

            if(3 > input.Length)
            {
                Console.WriteLine("Error: more than 3 parameters were entered.");
            }
            var number1 = IsDouble(input[0]);
            var op = input[1][0];
            var number2 = IsDouble(input[2]);

            if(null == number1 || null == number2)
            {
                Console.WriteLine("Error: numbers of type different from double were entered.");
            }
            ICalculator calc = new Calc();
            double result= calc.Calculate(op, number1.Value, number2.Value);
            Console.WriteLine(result);

            Console.WriteLine("Press enter to quit..");
            Console.ReadLine();
        }
       
        public static double? IsDouble(string str)
        {
            double number;
            return double.TryParse(str, out number) ? number : (double?)null;
        }
    }
}
