﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Calculator;

namespace CalculatorUnitTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void Calc_Add_BothPositive()
        {
            ICalculator calc = new Calc();
            double addResult = calc.Add(1, 3);
            Assert.AreEqual(4, addResult);
        }

        [TestMethod]
        public void Calc_Add_SingleZero()
        {
            ICalculator calc = new Calc();
            double addResult = calc.Add(10, 0);
            Assert.AreEqual(10, addResult);
        }
       
        [TestMethod]
        public void Calc_Add_TwoZeros()
        {
            ICalculator calc = new Calc();
            double addResult = calc.Add(0, 0);
            Assert.AreEqual(0, addResult);
        }

        [TestMethod]
        public void Calc_Add_Commutative()
        {
            ICalculator calc = new Calc();
            var first = 42;
            var second = 777;
            Assert.AreEqual(calc.Add(first, second), calc.Add(second, first));
        }

        [TestMethod]
        public void Calc_Add_AddSingleNegative()
        {
            ICalculator calc = new Calc();
            var result = calc.Add(1, -1);
            Assert.AreEqual(0, result);
        }

        [TestMethod]
        public void Calc_Add_AddTwoNegative()
        {
            ICalculator calc = new Calc();
            var result = calc.Add(-1, -1);
            Assert.AreEqual(-2, result);
        }


        [TestMethod]
        public void Calc_Sub_BothPositive()
        {
            ICalculator calc = new Calc();
            double addResult = calc.Sub(8, 3);
            Assert.AreEqual(5, addResult);
        }

        [TestMethod]
        public void Calc_sub_SingleZero()
        {
            ICalculator calc = new Calc();
            double addResult = calc.Sub(10, 0);
            Assert.AreEqual(10, addResult);
        }

        [TestMethod]
        public void Calc_Sub_TwoZeros()
        {
            ICalculator calc = new Calc();
            double addResult = calc.Sub(0, 0);
            Assert.AreEqual(0, addResult);
        }

        [TestMethod]

        [TestMethod]
        public void Calc_Sub_SubSingleNegative()
        {
            ICalculator calc = new Calc();
            var result = calc.Sub(1, -1);
            Assert.AreEqual(2, result);
        }

        [TestMethod]
        public void Calc_Sub_SubTwoNegative()
        {
            ICalculator calc = new Calc();
            var result = calc.Sub(-1, -1);
            Assert.AreEqual(0 result);
        }
    }
}
