﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicTacToe
{
    class TicTacToeGame
    {
        char[,] board;
        CharEnumerator ce;
        public TicTacToeGame()
        {
            board = new char[3, 3] { { '1', '2', '3' }, { '4', '5', '6' }, { '7', '8', '9'} };
        }

        public void display()
        {
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Console.WriteLine(board[i,j]);
                }
            }
        }

        public void move(char player, int x, int y)
        {
            if (isLegal(player, x, y))
            {
                board[x, y] = player;
            }
        }

        public bool isLegal(char player, int x, int y)
        {
            if (x > 3 || x < 0 || y > 3 || y < 0 || board[x, y]=='X' || board[x, y] == 'Y')
            {
                Console.WriteLine("The positon is out of range or caught. ");
                return false;
            }
                
            return true;
        }

        public bool IsGameOver
        {
            get
            {
                // check rows
                if (board[0, 0] ==  board[0, 1]  && board[0, 1]== board[0, 2]) { return true; }
                if (board[1, 0] ==  board[1, 1]  && board[1, 2] == board[1, 1]) { return true; }
                if (board[2, 0] ==  board[2, 1]  && board[2, 2] == board[2, 1]) { return true; }

                // check columns
                if (board[0, 0] ==  board[1, 0] && board[2, 0] == board[1, 0]) { return true; }
                if (board[0, 1] ==  board[1, 1] && board[2, 1] == board[1, 1]) { return true; }
                if (board[0, 2] ==  board[1, 2] && board[2, 2] == board[1, 2]) { return true; }

                // check diags
                if (board[0, 0] ==  board[1, 1] && board[1, 1] == board[2, 2] ) { return true; }
                if (board[0, 2] ==  board[1, 1]  && board[1, 1]==board[2, 0] ) { return true; }

                return false;
            }
        }
       

    }
}
