﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicTacToe
{
    class Program
    {
        static void Main(string[] args)
        {
            var newGame = new TicTacToeGame();
            while (true)
            {
                Console.WriteLine("Enter your player's symbol and the desired position in the form: symbol x, y");
                var input = Console.ReadLine().Split(new[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);

                if (3 > input.Length)
                {
                    Console.WriteLine("Error: more than 3 parameters were entered.");
                }
                var player = input[0][0];
                var x = int.Parse(input[1]);
                var y = int.Parse(input[2]);

                if (player == ' ' || x == ' ' || y == ' ')
                {
                    Console.WriteLine("Error: Illegal input. Enter only 3 chars.");
                }
                newGame.move(player, x, y);
                if (newGame.IsGameOver)
                {
                    Console.WriteLine("The game is over!");
                    break;
                }
            }
            Console.ReadLine();
        }
    }
}
