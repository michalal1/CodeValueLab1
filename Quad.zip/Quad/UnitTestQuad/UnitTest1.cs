﻿using System;
using Quad;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestQuad
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void Quad_Solver_TwoSolutions()
        {
            ICalc calc = new Calc();
            double x1;
            double x2;
            double addResult = calc.Solver(1, 7,10,out x1,out x2);
            Assert.AreEqual(2, addResult);
        }
    }
}
