﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quad
{
    public class Calc : ICalc
    {
        public int Solver(double a, double b, double c, out double x1, out double x2)
        {
            int IsSolution = 2;
            x1 = 0;
            x2 = 0;
            double d = b * b - 4 * a * c;
            if (d < 0)
            {
                IsSolution = 0;
            }
            else if (d > 0)
            {
                x1 = (-b + Math.Sqrt(d)) / (2 * a);
                x2 = (-b - Math.Sqrt(d)) / (2 * a);
                
            }
            else
            {
                IsSolution = 1;
                x1 = -b / (2 * a);
            }   
            return IsSolution;
        }
    }
}
