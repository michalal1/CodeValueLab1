﻿namespace Quad
{
    public interface ICalc
    {
        int Solver(double a, double b, double c, out double x1, out double x2);
    }
}