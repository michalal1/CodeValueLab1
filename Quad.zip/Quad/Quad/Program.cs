﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quad
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a ,b and c for the equation: a*x^2+b*x+c=0:");
            var input = Console.ReadLine().Split(new[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);

            if (3 != input.Length)
            {
                Console.WriteLine("Error: more or less than 3 parameters were entered.");
            }
            var a = IsDouble(input[0]);
            var b = IsDouble(input[1]);
            var c = IsDouble(input[2]);
            double x1 = 0;
            double x2 = 0;

            if (null == a || null == b || null == c)
            {
                Console.WriteLine("Error: parameters of type different from double were entered.");
            }
            ICalc calc = new Calc();
            int result = calc.Solver(a.Value, b.Value, c.Value, out x1, out x2);
            switch (result)
            {
                case 0:
                    Console.WriteLine("No solutions");
                    break;
                case 1:
                    Console.WriteLine("One solution: {0}",x1);
                    break;
                case 2:
                    Console.WriteLine("One solution: {0}, {1}", x1, x2);
                    break;
            }
            Console.WriteLine("Press enter to quit..");
            Console.ReadLine();
        }

        public static double? IsDouble(string str)
        {
            double number;
            return double.TryParse(str, out number) ? number : (double?)null;
        }

    
    }
}
