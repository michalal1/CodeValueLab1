﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AccountsLib;
namespace ConsoleApplication
{
    public class Program
    {
        static void Main(string[] args)
        {
            Account account1= AccountFactory.CreateAccount();
            Account account2 = AccountFactory.CreateAccount();
            try
            {
                Console.WriteLine("How much money you want to deposit?");
                int x = int.Parse(Console.ReadLine());
                account1.Deposit(x);
            }
            catch (ArgumentOutOfRangeException e)
            {
                Console.WriteLine(e.Message);
            }
            try
            {
                Console.WriteLine("How much money you want to withdraw?");
                var y = int.Parse(Console.ReadLine());
                account1.Withdraw(y);
            }
            catch (ArgumentOutOfRangeException e)
            {
                Console.WriteLine(e.Message);
            }
            catch(InsufficientFundsException e)
            {
                Console.WriteLine(e.Message);
            }

            Console.WriteLine("Your account balance is {0}",account1._balance);
            Console.WriteLine("Enter transfer amount to account number {0} :", account2._ID);
            var amount = int.Parse(Console.ReadLine());
            account1.Transfer(account2, amount);
            Console.WriteLine("Your account balance is {0}", account1._balance);
            account1.Transfer(account2, -3);
        }
    }
}
