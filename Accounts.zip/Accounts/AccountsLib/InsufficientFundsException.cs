﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccountsLib
{
    public class InsufficientFundsException : Exception
    {
        string message= "This withdrawing will get your balance into overdraft.";
        public override string Message
        {
            get
            {
                return message;
            }
        }
    }
}
