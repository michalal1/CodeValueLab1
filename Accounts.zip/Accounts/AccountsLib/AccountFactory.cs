﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace AccountsLib
{
    public static class AccountFactory
    {
        public static int _account_number = 0;
        static public Account CreateAccount(int initial_balance)
        {
            _account_number++;
            int new_id = _account_number;
            var new_account = new Account(new_id);
            new_account.Deposit(initial_balance);
            return new_account;
        }

        static public Account CreateAccount()
        {
            _account_number++;
            int new_id = _account_number;
            var new_account = new Account(new_id);
            return new_account;
        }
    }
}
