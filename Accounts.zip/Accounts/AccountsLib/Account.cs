﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccountsLib
{
    public class Account
    {
        public int _ID;
        public int _balance;
        public Account(int id)
        {
            _ID = id;
            _balance = 0;
        }
        
        public int GetID
        {
            get { return _ID; }
        }

        public void Deposit(int x)
        {
            if (x < 0)
            {
                string msg = "You cant deposit a negative value!";
                throw new ArgumentOutOfRangeException(msg);
            }
            _balance += x;
            return;
        }

        public void Withdraw(int x)
        {
            if (x < 0)
            {
                string msg = "You cant withdraw a negative value!";
                throw new ArgumentOutOfRangeException(msg);
            }
            if (_balance - x > 0)
                _balance -= x;
            else
                throw new InsufficientFundsException();
            return;
        }

        public void Transfer(Account account, int amount)
        {
            int intialAmount = _balance;
            try
            {
                Withdraw(amount);
                account.Deposit(amount);
                Console.WriteLine("A transfer attempt has been made.");
            }
            finally
            {
                Console.WriteLine("The amount before the transfer: {0}", intialAmount);
                Console.WriteLine("The current amount after the transfer: {0}", _balance);
            }
            return;
        }
    }

    
}
