﻿using System;


namespace Rationals
{
    class Program
    {
        static void Main(string[] args)
        {
            Rational x = new Rational(5, 15);
            Rational y = new Rational(6, 18);
            Rational z = new Rational(1, 13);
            Rational w = new Rational(7);
            Console.WriteLine("{0}/{1}", x.getNumerator, x.getDenomirator);
            x.Reduce();
            Console.WriteLine("{0}/{1}", x.getNumerator, x.getDenomirator);
            double Xdouble = x.DoubleForm;
            var AddResult = x.Add(y);
            var MulResult = x.Mul(y);
            var IsEquals = x.Equals(y);
            Console.WriteLine(AddResult);
            Console.WriteLine(MulResult);
            Console.WriteLine(Xdouble);
            string str = w.ToString();
            Console.ReadLine();
        }
    }
    public struct Rational
    {
        int _numerator;
        int _denomirator;
        public Rational(int x, int y)
        {
            _numerator = x;
            _denomirator = y;
        }

        public Rational(int x)
        {
            _numerator = x;
            _denomirator = 1;
        }

        public int getNumerator
        {
            get { return _numerator; }
        }

        public int getDenomirator
        {
            get { return _denomirator; }
        }

        public double DoubleForm
        {
            get
            {
                double res = _numerator / _denomirator;
                return res;
            }
        }

        public Rational Add(Rational num)
        {
            int newNumerator = _numerator * num._denomirator + num._numerator * this._denomirator;
            int newDenomirator = _denomirator * num._denomirator;
            var res=new Rational(newNumerator, newDenomirator);
            return res;
        }

        public Rational Mul(Rational num)
        {
            int newNumerator = this._numerator * num._numerator;
            int newDenomirator = this._denomirator * num._denomirator;
            var res = new Rational(newNumerator, newDenomirator);
            return res;
        }
    
        public void Reduce()
        {
            int RationalGCD = GCD(this._numerator, this._denomirator);
            this._numerator /= RationalGCD;
            this._denomirator /= RationalGCD;
        }

        public int GCD(int a, int b)
        {
            while (b > 0)
            {
                int rem = a % b;
                a = b;
                b = rem;
            }
            return a;
        }

        public bool Equals(Rational x)
        {
            this.Reduce();
            x.Reduce();
            return (this._numerator == x._numerator) && (this._denomirator == x._denomirator);
        }

        public override string ToString()
        {
            double num = this._numerator / this._denomirator;
            return Convert.ToString(num);
        }
    }
}
