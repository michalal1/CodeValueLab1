﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Strings
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("Enter a string:");
                string s = Console.ReadLine();
                if (string.IsNullOrEmpty(s))
                {
                    Console.WriteLine("The string is empty.");
                    return;
                }
                char[] c = { ' ' };
                var sub_s = s.Split(c,StringSplitOptions.RemoveEmptyEntries);
                Console.WriteLine(sub_s.Length);
                foreach (var token in sub_s.Reverse())
                {
                    Console.WriteLine("{0}", token);
                }
                Array.Sort(sub_s);
                foreach (var token in sub_s)
                {
                    Console.Write("{0} ", token);
                }
                Console.WriteLine("");
            }



        }
    }
}
